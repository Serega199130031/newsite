
 new Swiper('.intro__works-body', {
	direction: 'horizontal',
	loop: true,
	slidesPerView: 1,
	сenteredSlides: false,
	loopAdditionalSlides: 1,
	loopFillGroupWithBlank: true,
	spaceBetween: 20,
	navigation: {
		nextEl: '.swiper-button-prev',
		prevEl: '.swiper-button-next'
	},
 	breakpoints: {
		1330: {
			slidesPerView: 4,
			
		},
		1024: {
			slidesPerView: 3,
			
		},
		625: {
			slidesPerView: 2,
			
		},
		380: {
			slidesPerView: 1,
			
		}
	 }, 
});


new Swiper('.image-slider', {
	direction: 'horizontal',
	loop: true,
	slidesPerView: 2,
	сenteredSlides: false,
	/* loopAdditionalSlides: 1,
	loopFillGroupWithBlank: true, */
	spaceBetween: 20,
	autoplay: {
		delay: 1500,
		disableOnInteraction: false,
	},
 	breakpoints: {
		1330: {
			slidesPerView: 4,
			delay: 1500,
			disableOnInteraction: false,
		},
		768: {
			slidesPerView: 3,
			delay: 1500,
			disableOnInteraction: false,
		},
		625: {
			slidesPerView: 2,
			delay: 1500,
			disableOnInteraction: false,
		},
		380: {
			slidesPerView: 2,
			delay: 1500,
			disableOnInteraction: false,
		}
	 }, 
});

















